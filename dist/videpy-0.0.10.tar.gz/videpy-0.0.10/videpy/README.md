# VidePY
## Useful Bayesian tools to analysis and visualization of the samples.

Based in statistical rethinking book.
