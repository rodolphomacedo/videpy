# videpy
## Useful Bayesian tools to analysis and visualization samples.
